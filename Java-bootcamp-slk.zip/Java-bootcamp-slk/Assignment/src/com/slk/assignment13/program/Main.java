package com.slk.assignment13.program;

import java.util.Random;

public class Main {
	
	public static String generatePassword(int length){
		Random r= new Random();

		String str="";
		String sc="~!@#$%^&*";
		String lower="abcdefghijklmnopqrstuvwxyz";
		String upper="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String num="0123456789";
     	str = str+upper.charAt(r.nextInt(upper.length()))+lower.charAt(r.nextInt(lower.length()))+
     			sc.charAt(r.nextInt(sc.length()))+num.charAt(r.nextInt(num.length()));
		
		String m =upper+lower+num+sc;
		
		for(int i=0;i<length-4;i++){
			str=str+m.charAt(r.nextInt(m.length()));
			
		}
		
		return str;
	}
	public static void main(String[] args) {
		String s= generatePassword(10);
		System.out.println(""+s);
	}

}
