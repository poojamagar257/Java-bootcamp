package com.slk.assignment11.program;

public class Main {

	public static String reverseByWords(String sentence) { 
		
		String arr[]=sentence.split(" ");
		String s1="";
		for(int i=(arr.length-1);i>=0;i--)
		{   
			s1=s1+" "+arr[i];
		}
		return s1; 
	}
	public static void main(String[] args) {
		String sentence = "my name is pooja";
		
       System.out.println(" "+reverseByWords(sentence));
	}

}
