package com.slk.assignment05.program;

public class Main {

	public static int sumOfPrimes(int from, int to) {

		int sum = 0;
		
		for (int i = from; i <= to; i++) {

			int d = 2;
			int x = i / 2;
			while (d <= x) {
				int r = i % d;
				if (r == 0) {
					break;

				}
				d++;

			}
			if (d > x) {
				sum = sum + i;
			}
		}
		return sum;

	}

	public static void main(String[] args) {
		
		
		System.out.println(" " +sumOfPrimes(5, 11));

	}

}
