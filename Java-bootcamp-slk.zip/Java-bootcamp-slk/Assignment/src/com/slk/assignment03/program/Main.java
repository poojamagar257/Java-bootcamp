package com.slk.assignment03.program;

public class Main {

	static boolean isPrimeNumber(int num) {
		int a = 2, limit = num / 2, rem;
		while (a <= limit) {
			rem = num % a;
			if (rem == 0) {
				return false;
			}
			a++;
		}

		return true;

	}

	public static void main(String[] args) {
		int n = 19;
		boolean f = isPrimeNumber(n);
		System.out.println(n + ": " + f);

	}

}
