package com.slk.assignment04.program;

public class Main {

	public static void sortThreeNumbers(int a, int b, int c) { 
		if(a > b && a > c){
			if(b > c){
			System.out.println(c+" "+b+" "+a);
		}
			else
			{
				System.out.println(b+" "+c+" "+a);
			}
		}
		else if(b > a && b > c){
			if(a > c)
			{
				System.out.println(c+" "+a+" "+b);
			}
			else
			{
				System.out.println(a+" "+c+" "+b);
			}
		}
		else if(c > a && c > b){
			if(a > b){
			System.out.println(b+" "+a+" "+c);
		}
			else{
				System.out.println(a+" "+b+" "+c);
			}
		}
	}

	public static void main(String[] args) {
		
		sortThreeNumbers(25555, 4504, 3000);
	}

}
