package com.slk.assignment14.program;

public class Combination {
	
	
	
	
	public static void printAllCombinations(String word) {
		char[]ch=word.toCharArray();
		char temp;
		String s1;
		String s2[];
		 
		for(int i=0;i<=ch.length;i++){
			for(int j=i;j<ch.length;j++){
				temp=ch[i];
				ch[i]=ch[j];
				ch[j]=temp;
				s1=new String(ch);
				System.out.println(s1);
			}
			
			
		}
	}

	public static void main(String[] args) {
              String s = "abc";
             printAllCombinations(s);
             
	}
}
