package com.slk.assignment12.program;

public class Main {
	 
	public static String inWords(int num) {
		String a[] = { "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine" };
		String b[] = { "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventen", "eighteen",
				"ninteen" };

		String aa[] = { "", "", "twenty", "thirty", "fourty", "fifty", "sixty", "seventy", "eighty", "ninety" };
        
		if(num<10){
			return a[num];
		}
		else if(num>=10 && num<20){
			return b[ num-10];
		}
		else if(num>=20 && num<100)
		{
			return aa[num/10]+" "+a[num%10];
		}
		else if(num>=100 && num<1000){
			return a[num/100]+" hundred "+inWords(num%100);
		}
		else if(num>=1000 && num<10000){
			return a[num/1000]+" thousand "+inWords(num%1000);
		}
		else if(num>=10000 && num<20000)
		{
			return b[(num/1000)-10]+" thousand "+inWords(num%1000);
		}
		else if(num>=20000 && num<100000){
			return aa[num/10000]+" " +inWords(num%10000);
		}
		else if(num>=100000 && num<1000000){
			return a[num/100000]+" lakh "+inWords(num%100000);
		}
		else if(num>=1000000 && num<2000000){
			return b[(num/100000)-10]+" lakh "+inWords(num%100000);
		}
		else if(num>=2000000 && num<10000000){
			return aa[num/1000000]+" "+inWords(num%1000000);
		}
		else if(num>=10000000 && num<100000000){
			return a[num/10000000]+" crore "+inWords(num%10000000);
		}
		else if(num>=100000000 && num<200000000){
			return b[(num/10000000)-10]+" crore "+inWords(num%10000000);
		}
		else if(num>=20000000 && num<1000000000){
			return a[num/10000000]+" "+inWords(num%10000000);
		}

		return null;

	}

	public static void main(String[] args) {
		int num =121212322;
		System.out.println(" " + inWords(num));
	}

}
