package com.slk.assignment09.program;

public class Main {

	public static int TotalDaysYear(int year) {
		int TotalDays = 0;
		
		for (year = 1900; year < 2018; year++) {
			if (year % 400 == 0 || year % 100 != 0 && year % 4 == 0) {
				TotalDays += 366;
			} else
				TotalDays += 365;
		}
		//System.out.println(TotalDays);
		return TotalDays;
	}

	public static int TotalDaysMonth(int year, int month) {
		int TotalDays = 0;
		int max = 0;
		for (int i = 1; i < month; i++) {			
			switch(i){
			
			case 2:if (year % 400 == 0 || year % 100 != 0 && year % 4 == 0) {max=29; break;}
			else{max=28; break;}
			case 4:
			case 6:
			case 9:
			case 11: max=30; break;
			default: max=31;
			
			
			
			}
			//System.out.println(max);
			TotalDays += max;
		}
		//System.out.println(TotalDays);
		return TotalDays;

	}

	public static void printCalendar(int month, int year) {
		
		int max;
		
		if (month < 1 || month > 12)

		{
			System.out.println("Invalid date");
		}

		switch (month) {
		case 2:
			if (year % 400 == 0 || year % 100 != 0 && year % 4 == 0) {
				max = 29;
			} else {
				max = 28;
			}
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			max = 30;
			break;
		default:
			max = 31;
		}

		String day1[] = { "Su", "Mo", "Tu", "We", "Th", "Fr", "Sa" };

		for (int d = 0; d < 7; d++) {

			System.out.print(day1[d]+" ");

		}
		System.out.println();

		int Total = TotalDaysYear(year) + TotalDaysMonth(year, month)+1;
		//System.out.println(Total);
		int a;
		a = Total % 7;
		for (int i = 0; i <a; i++) {
			System.out.print("   ");

		}
		for (int i = 1; i <= max; i++) {
			System.out.printf("%2d"+" ",i);
			if ((i + a) % 7 == 0) {
				System.out.println();
			}

		}

	}

	public static void main(String[] args) {
		printCalendar(11, 2018);
	}

}
