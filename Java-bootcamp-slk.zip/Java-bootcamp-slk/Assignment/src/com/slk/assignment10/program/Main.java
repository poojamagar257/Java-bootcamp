package com.slk.assignment10.program;

import java.util.Arrays;

public class Main {
	

	public static int[] sumOfEvensAndOdds(int []nums) { 
		
		int sumofeven =0;
		int sumofodd = 0;
		int []arr = new int[2];
		
		for(int i =0;i <nums.length;i++)
		{
			if(nums[i]%2 == 0){
			sumofeven+=nums[i];
			
			}
			else{
				sumofodd+=nums[i];
				
			}
			
		}
		arr[0]=sumofeven;
		arr[1]=sumofodd;
		
		return arr;
	}



	public static void main(String[] args) {
		int [] nums = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; 
		int [] result = sumOfEvensAndOdds(nums);
				
		System.out.println("Sum of even and odd : arr[] = "+Arrays.toString(result));
	}

}
