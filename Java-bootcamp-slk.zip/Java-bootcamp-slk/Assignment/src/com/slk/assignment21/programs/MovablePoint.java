package com.slk.assignment21.programs;

public class MovablePoint implements Movable {
	// instance variables
	int x, y, xSpeed, ySpeed; // package access

	// Constructor
	public MovablePoint(int x, int y, int xSpeed, int ySpeed) {
		super();
		this.x = x;
		this.y = y;
		this.xSpeed = xSpeed;
		this.ySpeed = ySpeed;
	}

	// Implement abstract methods declared in the interface Movable
	public void moveUp() {
		y -= ySpeed; // y-axis pointing down for 2D graphics
	}

	public void moveDown() {
       y += ySpeed;
	}

	public void moveLeft() {
      x  -= xSpeed;
	}

	public void moveRight() {
       x += xSpeed;
	}

	@Override
	public String toString() {
		return "MovablePoint [x=" + x + ", y=" + y + ", xSpeed=" + xSpeed + ", ySpeed=" + ySpeed + "]";
	}
	

}