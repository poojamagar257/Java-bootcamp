package com.slk.assignment21.programs;

public interface Movable {
	
	void moveUp();
	void moveDown();
	void moveLeft();
	void moveRight();

}
