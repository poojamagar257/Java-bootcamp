package com.slk.assignment19.program;

public class CalenderValidation {

	public static int[][] calendar(String s) {

		int year, month;
		String[] input;
		input = s.split("-");
		if (input[0].length() != 4 || input[1].length() != 2) {
			throw new InvalidInputException("Please enter the input in YYYY-MM Format!");
		}
		year = Integer.parseInt(input[0]);
		month = Integer.parseInt(input[1]);
		return printCalendar(year, month);

	}

	public static int[][] printCalendar(int year, int month) {

		int week;
		int total;
		int max = 0;
		int k = 1;
		int h = 0;
		int a[][] = new int[5][7];

		if (month < 1 || month > 12 || year < 1900) {
			throw new InvalidDateException("The month must lie between 1-12 and the year should be >=1900");
		} else {
			max = maxDays(month, year);
		}

		total = totalDaysYear(year) + totalDaysMonth(year, month) + 1;
		week = total % 7;

		int i = 0;
		for (int j = 0; j < week; j++) {

			a[i][j] = 0;
			h++;

		}

		for (int m = 0; m < 5; m++) {
			for (int n = h; n < 7; n++) {

				if (k <= max) {
					a[m][n] = k;
					k++;
				}

			}
			h = 0;
		}
		return a;

	}

	public static boolean isLeap(int year) {
		return year % 400 == 0 || year % 4 == 0 && year % 100 != 0;
	}

	public static int maxDays(int month, int year) {
		int max;
		switch (month) {
		case 2:
			if (isLeap(year)) {
				max = 29;
			} else {
				max = 28;
			}
			break;

		case 4:
		case 6:
		case 9:
		case 11:
			max = 30;
			break;

		default:
			max = 31;

		}
		return max;
	}

	public static int totalDaysYear(int year) {
		int totalDays = 0;
		for (int j = 1900; j < year; j++) {
			if (j % 400 == 0 || j % 4 == 0 && j % 100 != 0) {
				totalDays += 366;
			} else {
				totalDays += 365;
			}
		}
		return totalDays;

	}

	public static int totalDaysMonth(int year, int month) {
		int days = 0;
		int max = 0;
		for (int i = 1; i < month; i++) {

			max = maxDays(i, year);
			days += max;

		}

		return days;
	}

	public static void main(String[] args) {
		try {
			int[][] b = calendar("2018-12");
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 7; j++) {
					System.out.print(b[i][j] + "\t" );

				}
				System.out.println();
			}
		} catch (InvalidDateException e) {

			System.out.println("Please enter valid Date!");
		} catch (InvalidInputException e) {
			System.out.println("Please enter the date in YYYY-MM Format!!");
		}
	}

}
