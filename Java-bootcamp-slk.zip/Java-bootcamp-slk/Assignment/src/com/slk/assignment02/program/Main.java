package com.slk.assignment02.program;

public class Main {
	static boolean isValidDate(int year, int month, int day) {
		int max = 0;
		switch (month) {
		case 2:
			if (year % 400 == 0 || year % 4 == 0 && year % 100 != 0) {
				max = 29;
				if (day <= max) {
					return true;
				} else {
					return false;
				}
			} else {
				max = 28;
				if (day <= max) {
					return true;
				}
			}
		case 4:
		case 6:
		case 9:
		case 11:

			if (day <= max) {
				max = 30;
				return true;
			}
		default:

			if (day <= max) {
				max = 31;
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args) {

		int y = 2016, m = 2, d = 29;
		boolean f = isValidDate(y, m, d);
		System.out.printf(" %d %d %d is validate date: %s", d, m, y, f);

	}

}
