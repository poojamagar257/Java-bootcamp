package com.slk.assignment06.program;

public class Main {

	public static int fibonacci(int index) {
		int a=-1;
		int b=1;
		int sum=0;
		
		for (int i = 0; i <= index; i++) {
			sum = a+b;
		    a=b;
		    b=sum;
		    System.out.print(" "+sum);
		}

		return sum;
	}

	public static void main(String[] args) {
		
		fibonacci(15);
	}

}
