package com.slk.assignment22.entity;

public enum Gender {
	MALE, FEMALE
}