
package com.slk.assignment22.dao;

import com.slk.assignment22.dao.impl.ContactsDaoArrayListImpl;
import com.slk.assignment22.dao.impl.ContactsDaoHashMapIpml;
import com.slk.assignment22.dao.impl.ContactsDaoJdbcImpl;

public final class DaoFactory {

	private static final String discriminator = "JDBC";

	private DaoFactory() {
	}

	public static ContactsDao getContactsDao() throws DaoException {
		switch (discriminator.toUpperCase()) {
		case "JDBC":
			 return new ContactsDaoJdbcImpl();
			 
		case "HASHMAP":
			return new ContactsDaoHashMapIpml();
		case "CSV":
			//return new ContactsDaoCsvImpl();
	
		case "ARRAYLIST":
			 return new ContactsDaoArrayListImpl();
			
		}
		throw new DaoException("No implementation found for discriminator: " + discriminator);
	}
}