package com.slk.assignment22.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.slk.assignment22.dao.ContactsDao;
import com.slk.assignment22.dao.DaoException;
import com.slk.assignment22.entity.Contact;
import com.slk.assignment22.utils.DbUtil;
import com.slk.assignment22.utils.KeyboardUtil;

public class ContactsDaoJdbcImpl implements ContactsDao{
//	String first_name, last_name, gender, email, phone, address, city, state, country;
//	int  pincode;
//	Date birth_date;
//	

	@Override
	public void addContact(Contact contact) throws DaoException {
		String sql = "insert into contact (first_name, last_name, gender, email, phone, address, city, state, pincode, country, birth_date) values (?,?,?,?,?,?,?,?,?,?,?)";
	
	try(Connection conn = DbUtil.newConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);)
	{
		while(true){
			stmt.setString(1, contact.getFirstname());
			stmt.setString(2, contact.getLastname());
			stmt.setString(3, contact.getGender().toString());
			stmt.setString(4, contact.getEmail());
			stmt.setString(5, contact.getPhone());
			stmt.setString(6, contact.getAddress());
			stmt.setString(7, contact.getCity());
			stmt.setString(8, contact.getState());
			stmt.setInt(9, contact.getPincode());
			stmt.setString(10, contact.getCountry());
			stmt.setDate(11, (java.sql.Date) contact.getBirthDate());
			
			stmt.executeUpdate();
			System.out.println("Data inserted successfully ");

		//	String choice = KeyboardUtil.getString("Do you want to add another ? yes/no (no): ");
		//	if (choice.equalsIgnoreCase("no")) {
				break;
//			}
		}
		
	}
	catch(Exception ex){
		ex.printStackTrace();//throw new DaoException(ex);
	}
	}

	@Override
	public Contact getContact(int id) throws DaoException {
		String sql = "select * from contact where id=?";
		try(Connection conn = DbUtil.newConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);)
		{
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			Contact c= null;
			if(rs.next()){
				do{
					c.setId(rs.getInt(id));
					c.setFirstname(rs.getString("firstname"));
					c.setLastname(rs.getString("lastname"));
					//c.setGender(rs.getString("gender"));
					c.setEmail(rs.getString("email"));
					c.setPhone(rs.getString("phone"));
					c.setAddress(rs.getString("address"));
					c.setCity(rs.getString("city"));
					c.setState(rs.getString("state"));
					c.setPincode(rs.getInt("pincode"));
					c.setCountry(rs.getString("country"));
					
					stmt.executeQuery();
				}while(rs.next());
			}
			else {
				System.out.println("No product found for Category :" + category);
			}
			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return null;
	}

	@Override
	public void updateContact(Contact contact) throws DaoException {
		
	}

	@Override
	public void deleteContact(int id) throws DaoException {
		
	}

	@Override
	public Contact getContactByEmail(String email) throws DaoException {
		return null;
	}

	@Override
	public Contact getContactByPhone(String phone) throws DaoException {
		return null;
	}

	@Override
	public List<Contact> getContactsByLastname(String lastname) throws DaoException {
		return null;
	}

	@Override
	public List<Contact> getContactsByCity(String city) throws DaoException {
		return null;
	}

	@Override
	public List<Contact> getContacts() throws DaoException {
		String sql = "select * from contact";
		List<Contact> list = new ArrayList<>();
		try(Connection conn = DbUtil.newConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);)
		{
			ResultSet rs = stmt.executeQuery();
			if(rs.next()){
				for (Contact c : list) {
					
				}
				
			}
		}
		catch(Exception ex){
			throw new DaoException(ex);
		}
		return list;
	}

	@Override
	public List<Contact> getContactsByBirthDate(Date from, Date to) throws DaoException {
		return null;
	}

}
