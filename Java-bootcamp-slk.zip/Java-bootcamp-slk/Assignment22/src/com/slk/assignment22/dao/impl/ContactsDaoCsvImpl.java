package com.slk.assignment22.dao.impl;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.slk.assignment22.dao.ContactsDao;
import com.slk.assignment22.dao.DaoException;
import com.slk.assignment22.entity.Contact;
import com.slk.assignment22.utils.KeyboardUtil;

public class ContactsDaoCsvImpl implements ContactsDao {

	String filename = "Contact.csv";
	private Map<Integer, Contact> map;
	FileWriter file ;
	PrintWriter out;
	
	public ContactsDaoCsvImpl() throws Exception {
		map = new HashMap<>();
		file = new FileWriter(filename, true);
		 out = new PrintWriter(file);
	}
	
	@Override
	public void addContact(Contact contact) throws DaoException {
		try(FileWriter writer = new FileWriter(filename,true);
				PrintWriter out = new PrintWriter(writer)){
			int id= KeyboardUtil.getInt("Enter id: ");
			String name= KeyboardUtil.getString("Enter name :");
			String email= KeyboardUtil.getString("Enter email id :");
			String city= KeyboardUtil.getString("Enter city :");
			
			out.printf("\n%d\t%s\t%s\t%s",id,name,email,city);
			
		}
		catch(Exception e){
			
		}
		map.put(contact.getId(), contact);
	}

	@Override
	public Contact getContact(int id) throws DaoException {
		return null;
	}

	@Override
	public void updateContact(Contact contact) throws DaoException {

	}

	@Override
	public void deleteContact(int id) throws DaoException {

	}

	@Override
	public Contact getContactByEmail(String email) throws DaoException {
		return null;
	}

	@Override
	public Contact getContactByPhone(String phone) throws DaoException {
		return null;
	}

	@Override
	public List<Contact> getContactsByLastname(String lastname) throws DaoException {
		return null;
	}

	@Override
	public List<Contact> getContactsByCity(String city) throws DaoException {
		return null;
	}

	@Override
	public List<Contact> getContacts() throws DaoException {
		return null;
	}

	@Override
	public List<Contact> getContactsByBirthDate(Date from, Date to) throws DaoException {
		return null;
	}
	
	

}
