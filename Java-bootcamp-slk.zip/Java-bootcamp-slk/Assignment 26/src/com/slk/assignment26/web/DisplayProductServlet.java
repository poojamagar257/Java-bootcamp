package com.slk.assignment26.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayProductServlet
 */
@WebServlet("/DisplayProductServlet")
public class DisplayProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	int id;
	String name, category;
	double price;

	String username = "Sa";
	String password = "";
	String driver = "org.h2.Driver";
	String url = "jdbc:h2:tcp://localhost/~/slk_training_2018_12";

	String sql = "select * from products where category=?";
	Connection conn;
	PreparedStatement stmt;
	ResultSet rs;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {

		try {
			Class.forName(driver);

			conn = DriverManager.getConnection(url, username, password);
			stmt = conn.prepareStatement(sql);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println("<h2>Product List</h2>");
		//String category=null;
		String input;
		input = request.getParameter("category");
		
		if (input != null) {
			try {
				stmt.setString(1,input);
				rs = stmt.executeQuery();

				if (rs.next()) {
					do {
						id = rs.getInt(1); // rs.getInt(id);
						name = rs.getString("name");
						price = rs.getDouble("price");
						out.println("<p>Id    : </p>" + id);
						out.println("<p>Name  : </p>" + name);
						out.println("<p>Price : Rs. </p>" + price);
						out.println("<hr/>");
					} while (rs.next());
				} else {
					out.println("<p>No product found for Category : </p>" +input);
				}
			
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		out.close();

	}

}
