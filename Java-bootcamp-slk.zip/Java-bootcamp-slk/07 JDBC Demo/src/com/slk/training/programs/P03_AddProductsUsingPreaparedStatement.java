package com.slk.training.programs;

import java.sql.Connection;
import java.sql.Statement;

import java.sql.PreparedStatement;
import com.slk.training.utils.DbUtil;
import com.slk.training.utils.KeyBoardUtil;

public class P03_AddProductsUsingPreaparedStatement {

	public static void main(String[] args) {

		int id;
		String name, category;
		double price;
		
		String sql = "Insert into products values(?,?,?,?)";
		
		try (Connection conn = DbUtil.newConnection();
				//conn.prepareStatement(sql) sends the SQL command, which
				//gets pre-complied and cached in the RDBMS server later
				PreparedStatement stmt = conn.prepareStatement(sql);
		) {
			while (true) {
				id = KeyBoardUtil.getInt("Enter id: ");
				name = KeyBoardUtil.getString("Enter name: ");
				category = KeyBoardUtil.getString("Enter category: ");
				price = KeyBoardUtil.getDouble("Enter Price : ");
				
				stmt.setInt(1, id);
				stmt.setString(2, name);
				stmt.setString(3, category);
				stmt.setDouble(4, price);
				
				//stmt.excuteUpdate() sends the parameters to the RDBMS
				//which will be used by the pre-complied SQL command,
				//cached in the RDBMS server.

				
				stmt.executeUpdate();//use executeUpdate for INSERT/UPDATE/DELETE
				System.out.println("Data inserted successfully ");

				String choice = KeyBoardUtil.getString("Do you want to add another ? yes/no (yes): ");
				if (choice.equalsIgnoreCase("no")) {
					break;
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}
