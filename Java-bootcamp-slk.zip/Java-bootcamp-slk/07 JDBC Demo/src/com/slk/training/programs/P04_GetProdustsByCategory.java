package com.slk.training.programs;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.slk.training.utils.DbUtil;
import com.slk.training.utils.KeyBoardUtil;

public class P04_GetProdustsByCategory {

	public static void main(String[] args) {

		int id;
		String name, category=KeyBoardUtil.getString("Enter Category: ");
		double price;

		String sql = "select * from products where category=?";

		try (Connection conn = DbUtil.newConnection(); 
			PreparedStatement stmt = conn.prepareStatement(sql);) {
			stmt.setString(1, category);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				do {
					id = rs.getInt(1); // rs.getInt(id);
					name = rs.getString("name");
					price = rs.getDouble("price");
					System.out.println("Id    : " + id);
					System.out.println("Name  : " + name);
					System.out.println("Price : Rs." + price);
					System.out.println();
				} while (rs.next());
			} else {
				System.out.println("No product found for Category :" + category);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
