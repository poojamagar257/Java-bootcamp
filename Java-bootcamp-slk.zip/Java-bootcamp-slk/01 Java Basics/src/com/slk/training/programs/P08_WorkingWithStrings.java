package com.slk.training.programs;

import com.slk.training.entity.Person;

public class P08_WorkingWithStrings {

	public static void main(String[] args) {
		String s1 = "Pooja";//creates a new String object and stores in a cache
		String s2 = "Pooja";// re-used from the cache
		
		System.out.println("s1==s2 is "+(s1==s2));//checks references
		System.out.println("s1.equals(s2) is: "+s1.equals(s2));// value check
		System.out.println();
	
		s1 = new String("Patil");
		s2 = new String("Patil");
		System.out.println("s1==s2 is "+(s1==s2));//checks references
		System.out.println("s1.equals(s2) is: "+s1.equals(s2));// value check
		
		Person p1,p2;
		p1 = new Person();
		p2 = new Person();
		p1.setName("Pooja");
		p2.setName("Pooja");
		System.out.println("p1==p2 is "+(s1==s2));//checks references
		System.out.println("p1.equals(p2) is: "+s1.equals(s2));// value check
		
		String text ="My name is Pooja and I live in Bangalore";
		System.out.println("lenght of text is "+text.length());
		System.out.println(text.toUpperCase());
		System.out.println(text.substring(0, 14));
		System.out.println(text);
		System.out.println("char at index 12 is : "+text.charAt(12));
		System.out.println("index of letter P is: "+text.indexOf("P"));
		System.out.println("index of word Bangalore is : "+text.indexOf("Bangalore"));
		System.out.println("index of word Mysore is: "+text.indexOf("Mysore"));
	
	}

}
