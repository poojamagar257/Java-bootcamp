package com.slk.training.programs;

import com.slk.training.entity.Person;

public class P07_WorkingWithPersonObjects {

	public static void main(String[] args) {
		Person p1;
		p1 = new Person();
		
		p1.setName("Pooja");
		p1.setAge(25);
		p1.setHeight(5.6);
		
		System.out.println("p1 is "+p1);
	}
}
