package com.slk.training.programs;

public class P05_UsingLoops {

	static void forLoopExample() {
		// print a multiplication table for a number
		int num = 76;
		// for(initializer; loop_condition; loop_controller) statement
		for (int i = 1; i <= 15; i++) {
			System.out.printf("%d X %d = %d\n", num, i, num * i);
		}
	}

	static void whileLoopExample() {
		// check if the given number is prime or not
		int num = 11;
		int d = 2, limit = num / 2, rem;
		while (d <= limit) {
			rem = num % d;
			if (rem == 0) {
				System.out.println(num + " is not a prime number!");
				break;
			}
			d++;
		}
		if (d > limit) {
			System.out.println(num + " is a prime number!");
		}
	}

	public static void main(String[] args) {
		// forLoopExample();
		whileLoopExample();
	}

}
