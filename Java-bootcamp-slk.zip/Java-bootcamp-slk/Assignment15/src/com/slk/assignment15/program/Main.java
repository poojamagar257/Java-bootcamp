package com.slk.assignment15.program;

import com.slk.assignment15.entity.Circle;
import com.slk.assignment15.entity.Cylinder;

public class Main {

	public static void main(String[] args) {
		Circle[] circles = {
				new Cylinder(12.34),
				new Cylinder(12.34, 10.0),
				new Cylinder(12.34, "blue", 10.0)
			};
		
		for(Circle c: circles){
			System.out.printf("area of circular region of Cylinder  with radius %f, color %s is %f & volume of Cylinder is %f \n:",c.getRadius(),c.getColor(),c.getArea(),((Cylinder) c).getVolume());
		}

	}

}

