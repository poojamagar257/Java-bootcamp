package com.slk.training.entity;

public abstract class Professor extends Person{

	//class Professor is abstract ,which means,
	// it can not be used for creating object.
	//Note that abstract class need not contain 
	// any abstract method. But if there is an
	//abstract method the class must be marked as abstract.
}
