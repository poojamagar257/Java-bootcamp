package com.slk.training.programs;

import com.slk.training.utils.KeyboardUtil;

import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.slk.training.cfg.AppConfig4;
import com.slk.training.cfg.AppConfig_5;
import com.slk.training.dao.DaoException;
import com.slk.training.dao.ProductDao;
import com.slk.training.dao.ProductDaoJdbcImpl;
import com.slk.training.entity.Product;;

public class P05_TestingJdbc01 {

	private ProductDao dao;
	public P05_TestingJdbc01() {
		AnnotationConfigApplicationContext ctx;
		ctx = new AnnotationConfigApplicationContext(AppConfig_5.class);
		 dao = ctx.getBean("jdbc", ProductDao.class);
	}

	public void start() {
		int choice;

		while ((choice = menu()) != 0) {

			switch (choice) {
			case 1:
				addProduct();
				break;
			case 2:
				searchProductById();
				break;
			case 3:
				Product productToEdit = searchProductById();
				if(productToEdit != null){
					editAndUpdateProduct(productToEdit);
				}
				break;
			case 4:
				Product productToDelete = searchProductById();
				if (productToDelete != null) {
					deleteProduct(productToDelete.getId());
				}
				break;
			case 5:
				totalCountOfProducts();
				break;
			case 6:
				listAllProducts();
				break;
			case 7:
				searchByPriceRange();
				break;
			case 8:
				getProductsByCategory();
				break;
			
			}
			}
		}

	private void addProduct() {
		Product p = new Product();
		p = getFieldValuesFromKeyboard(p);

		try {
			dao.addProduct(p);
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}

	private Product searchProductById() {
		try {
			int id = KeyboardUtil.getInt("Enter id for searching Product: ");
			Product p = dao.getProduct(id);
			if (p == null) {
				System.out.println("No Product found for id " + id);
				return null;
			}

			printProductDetails(p);

			return p;

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Invalid input. Please try agian!");
		}
		return null;

	}
	private void totalCountOfProducts(){
		try {
			int n = dao.count();
			System.out.println("Total products: "+n);
		} catch (DaoException e) {
			e.printStackTrace();
		}
		
	}

	private void printProductDetails(Product product) {
		System.out.println("Id          : " + product.getId());
		System.out.println("Name        : " + product.getName());
		System.out.println("Category    : " + product.getCategory());
		System.out.println("Price       : " + product.getPrice());

	}
	
	private void editAndUpdateProduct(Product product) {
		String choice = getString("Do you want to edit details? (yes/no)", "yes");
		if (choice.equalsIgnoreCase("yes")) {
			product = getFieldValuesFromKeyboard(product);
			try {
				dao.updateProduct(product);
				System.out.println("Product details updated successfully!");
				line("=");
			} catch (DaoException e) {
				e.printStackTrace();
			}

		}
	}

	private void deleteProduct(int id) {
		String choice = getString("Do you want to delete this record? (yes/no)", "no");
		if (choice.equalsIgnoreCase("yes")) {
			try {
				dao.deleteProduct(id);
				System.out.println("Product deleted successfully!");
			} catch (DaoException e) {
				e.printStackTrace();
			}
		}
	}

	private void getProductsByCategory() {
		String category = KeyboardUtil.getString("Enter category to search products: ");
		try {
			List<Product> list = dao.getProductsByCategory(category);
			printProducts(list);
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}
	
	private void searchByPriceRange() {
		double min = KeyboardUtil.getDouble("Enter minimum range of price: ");
		double max = KeyboardUtil.getDouble("Enter maximum range of price: ");

		try {
			List<Product> list = dao.getProductsByPriceRange(min, max);
			printProducts(list);
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}

	private void listAllProducts() {
		List<Product> list;
		try {
			list = dao.getProducts();
			printProducts(list);
		} catch (DaoException e) {
			e.printStackTrace();
		}
	}
	
	private void printProducts(List<Product> list) {
		if (list == null) {
			return;
		}

		if (list.size() == 0) {
			System.out.println("The search did not match any records!");
			return;
		}

		line("-");
		System.out.printf("%3s %-30s %-30s %-15s \n", "Id", "Name", "Category", "Price");
		line("-");
		for (Product p : list) {

			System.out.printf("%3d %-30s %-30s %-15s \n", p.getId(), p.getName(), p.getCategory(), p.getPrice());

		}

	}

	private Product getFieldValuesFromKeyboard(Product product) {
		product = copyOf(product);
		product.setId(getInt("Id", product.getId()));
		product.setName(getString("Name", product.getName()));
		product.setCategory(getString("Category", product.getCategory()));
		product.setPrice(getDouble("Price", product.getPrice()));

		return product;
	}

	private Product copyOf(Product product) {
		Product p = new Product();
		p.setId(product.getId());
		p.setName(product.getName());
		p.setCategory(product.getCategory());
		p.setPrice(product.getPrice());
		return p;
	}

	private String getString(String field, String value) {
		String msg = String.format("%s %s", field, value == null ? "" : "(" + value + ") ");
		String input = KeyboardUtil.getString(msg);
		if (input.trim().equals("")) {
			input = value;
		}
		return input;
	}

	private Integer getInt(String field, Integer value) {
		String msg = String.format("%s %s", field, value == null ? "" : "(" + value + ") ");
		String input = KeyboardUtil.getString(msg);
		if (input.trim().equals("")) {
			return value;
		}
		try {
			return Integer.parseInt(input);
		} catch (NumberFormatException e) {
			return null;
		}
	}

	private Double getDouble(String field, Double value) {
		String msg = String.format("%s %s", field, value == null ? "" : "(" + value + ") ");
		String input = KeyboardUtil.getString(msg);
		if (input.trim().equals("")) {
			return value;
		}
		try {
			return Double.parseDouble(input);
		} catch (NumberFormatException e) {
			return null;
		}
	}

	public int menu() {

		while (true) {
			line("~");

			System.out.println("1. Add new Product");
			System.out.println("2. Search by Id");
			System.out.println("3. Edit Product");
			System.out.println("4. Delete Product");
			System.out.println("5. Total count of Product");
			System.out.println("6. List all contacts");
			System.out.println("7. Search by price range");
			System.out.println("8. Search by Category");

			line("~");
			try {
				int choice = KeyboardUtil.getInt("Enter your choice (0 to exit): ");
				if (choice < 0 || choice > 8) {
					System.out.println("Invalid choice. Please try again!");
				} else {
					return choice;
				}
			} catch (Exception e) {
				System.out.println("Only integers are acceptable. Please try again!");
			}
		}
	}

	private void line(String ch) {
		for (int i = 0; i < 90; i++) {
			System.out.print(ch);
		}
		System.out.println();
	}

	public static void main(String[] args) {
		

		new P05_TestingJdbc01().start();
		
	}

}
