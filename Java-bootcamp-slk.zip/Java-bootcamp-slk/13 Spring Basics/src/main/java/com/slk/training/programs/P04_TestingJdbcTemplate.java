package com.slk.training.programs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.slk.training.cfg.AppConfig_5;
import com.slk.training.entity.Product;

public class P04_TestingJdbcTemplate {
	
	private static JdbcTemplate template;
	
	static class ProductRowMapper implements RowMapper<Product>{

		@Override
		public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
			Product p = new Product();
			p.setId(rs.getInt("id"));
			p.setName(rs.getString("name"));
			p.setCategory(rs.getString("category"));
			p.setPrice(rs.getDouble("price"));
			return p;
		}
		
	}
	
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx;
		ctx = new AnnotationConfigApplicationContext(AppConfig_5.class);
		
		template = ctx.getBean(JdbcTemplate.class);
		printProductCount();
		printProductNameForId(7);
		printProductDetailsForId(5);
		updateProductPriceForId(5,1000.0);
		printAllProductNamesAndPrices();
		getProductForId(5);
		getAllPrducts();
		ctx.close();
		
	}

	static void getAllPrducts() {

		List<Product> list = template.query("select * from products", new ProductRowMapper());
		System.out.println("All products: ");
		for (Product p : list) {
			System.out.println(p);
		}
		System.out.println();
	}

	static void getProductForId(int id) {
		String sql = "select * from products where id = ? ";
		ProductRowMapper prm = new ProductRowMapper();
		// prm knows how to convert a row (ResultSet) into a Product Instance
		Product p = template.queryForObject(sql, prm, id);
		System.out.println(p);
	}

	static void updateProductPriceForId(int id, double incr) {

		String sql ="update products set price = price + ? where id = ?";
		int uc = template.update(sql, incr, id);
		System.out.printf("%d row/s updated\n", uc);
		
	}

	static void printAllProductNamesAndPrices() {

		String sql ="select * from products";
		// the query produces multiple rows, multiple columns
		//use the queryForList function
		List<Map<String, Object>> list = template.queryForList(sql);
		System.out.println("\nProduct names and prices are: ");
		for (Map<String, Object> row : list) {
			System.out.printf("%-30s %10.2f\n",row.get("name"), row.get("price"));
		}
		
	}

	static void printProductDetailsForId(int id) {

		String sql = "select * from products where id = ?";
		// use queryForMap when the sql results in 1 row multiple column
		Map<String, Object> row = template.queryForMap(sql, id);
		System.out.println("\nProducts details for id "+id);
		System.out.println("Name     : "+row.get("name"));
		System.out.println("Category : "+row.get("Category"));
		System.out.println("Price    : Rs."+row.get("price"));
	}

	static void printProductNameForId(int id) {

		//query result in 1 row 1 column
		String sql = "select name from products where id=?";
		String name = template.queryForObject(sql, String.class, id);
		System.out.printf("Name (id=%d) : %s\n",id,name);
	}

	static void printProductCount() {

		// use queryForObject when the Sql returns 1 row 1 column exactly
		int pc = template.queryForObject("select count(*) from products", Integer.class);
		System.out.println("There are "+pc+" products.");
	}
	

}
