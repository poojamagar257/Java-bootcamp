package com.slk.training.programs;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.slk.training.cfg.AppConfig5;
import com.slk.training.dao.DaoException;
import com.slk.training.dao.ProductDao;
import com.slk.training.entity.Product;

public class P06_TestingCsv01 {

	public static void main(String[] args) throws DaoException {

		AnnotationConfigApplicationContext ctx;
		ctx = new AnnotationConfigApplicationContext(AppConfig5.class);

		ProductDao dao = ctx.getBean("csv", ProductDao.class);
		//int pc = dao.count();
		Product p =new Product();
         dao.addProduct(p);
	//	System.out.println("There are " + pc + " products.");

		ctx.close();
	}

}
