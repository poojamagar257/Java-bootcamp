package com.slk.training.dao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.slk.training.entity.Product;
import com.slk.training.utils.KeyboardUtil;

public class ProductDaoCsvImpl implements ProductDao {

	public ProductDaoCsvImpl() {

		// System.out.println("ProductDaoCsvImpl Instance created");
	}

	@Override
	public int count() throws DaoException {
		throw new DaoException("method not implemented yet");
	}

	@Override
	public void addProduct(Product product) throws DaoException {
		String filename = "product.csv";// contains tab separated values

		try (FileWriter writer = new FileWriter(filename, true); PrintWriter out = new PrintWriter(writer)) {

			int id = KeyboardUtil.getInt("Enter id: ");
			String name = KeyboardUtil.getString("Enter name :");
			String category = KeyboardUtil.getString("Enter category :");
			double price = KeyboardUtil.getDouble("Enter price:");

			out.printf("\n%d\t%s\t%s\t%s", id, name, category, price);
		} catch (Exception e) {

		}
		System.out.println("Data appened to the file ");

	}

	@Override
	public Product getProduct(int id) throws DaoException {
		String filename = "product.csv";

		try (FileReader reader = new FileReader(filename); BufferedReader in = new BufferedReader(reader)) {
			String line;
			in.readLine(); 
			while ((line = in.readLine()) != null) {
				String[] ar = line.split("\t");
				System.out.println("Id       : " + ar[0]);
				System.out.println("Name     : " + ar[1]);
				System.out.println("Category : " + ar[2]);
				System.out.println("Price    : " + ar[3]);
				System.out.println();
			}

		} catch (Exception e) {

		}
		return null;
	}

	@Override
	public void updateProduct(Product product) throws DaoException {
		throw new DaoException("method not implemented yet");

	}

	@Override
	public void deleteProduct(int id) throws DaoException {

	}

	@Override
	public List<Product> getProducts() throws DaoException {
		String filename = "product.csv";// contains tab separated values

		List<String> list = new ArrayList<>();
		try (FileReader reader = new FileReader(filename); BufferedReader in = new BufferedReader(reader)) {
			String line;
			in.readLine(); // skip the header line
			while ((line = in.readLine()) != null) {
				String[] ar = line.split("\t");
				System.out.println("Id         : " + ar[0]);
				System.out.println("Name       : " + ar[1]);
				System.out.println("Category   : " + ar[2]);
				System.out.println("price      : " + ar[3]);
				System.out.println();
			}

		} catch (Exception e) {

		}
		return null;
	}

	@Override
	public List<Product> getProductsByPriceRange(double min, double max) throws DaoException {
		throw new DaoException("method not implemented yet");

	}

	@Override
	public List<Product> getProductsByCategory(String category) throws DaoException {
		throw new DaoException("method not implemented yet");

	}

}
