package com.slk.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.slk.training.entity.Product;

@Component("jdbc")
public class ProductDaoJdbcImpl implements ProductDao {

	private String driver;
	private String url;
	private String user;
	private String password;

	@Autowired(required = false)
	private DataSource dataSource;

	// spring calls this constructor by default
	public ProductDaoJdbcImpl() {

		System.out.println("An object of ProductDaoImpl is created using default constructor");
	}

	// spring can call this constructor via constructor-injection
	public ProductDaoJdbcImpl(String driver, String url, String user, String password) {
		System.out.println("An object of ProductDaoImpl is created using overloaded constructor");

		this.driver = driver;
		this.url = url;
		this.user = user;
		this.password = password;
	}

	// parameterized constructor for dependency injection
	public ProductDaoJdbcImpl(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	// spring can call any setter via property-injection(setter injection)
	// a setter is also known as a writable property or a mutator
	// if name of the setter is "setDriver" , the name of the property is
	// "driver"
	public void setDriver(String driver) {
		this.driver = driver;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	// setter property called "jdbcInfo"
	public void setJdbcInfo(String[] info) {
		driver = info[0];
		url = info[1];
		user = info[2];
		password = info[3];
	}

	public void setJdbcMap(Map<String, String> map) {
		driver = map.get("jdbc.driver");
		url = map.get("jdbc.url");
		user = map.get("jdbc.user");
		password = map.get("jdbc.password");
	}

	private Connection openConnection() throws SQLException, ClassNotFoundException {

		if (dataSource != null) {
			return dataSource.getConnection();
		}
		Class.forName(driver);
		return DriverManager.getConnection(url, user, password);
	}

	@Override
	public int count() throws DaoException {
		String sql = "select count(*) from products";
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();) {
			rs.next();
			return rs.getInt(1);

		} catch (Exception ex) {
			throw new DaoException(ex);
		}
	}

	@Override
	public void addProduct(Product product) throws DaoException {
		String sql = "insert into products values(?,?,?,?)";
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				) {

			stmt.setInt(1, product.getId());
			stmt.setString(2, product.getName());
			stmt.setString(3, product.getCategory());
			stmt.setDouble(4, product.getPrice());
			stmt.executeUpdate();

		} catch (Exception ex) {
			throw new DaoException(ex);
		}
	}

	@Override
	public Product getProduct(int id) throws DaoException {
		String sql = "select * from products where id = ?";
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				) {
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				return p;
			}
		} catch (Exception ex) {
			throw new DaoException(ex);
		}
		return null;
	}

	@Override
	public void updateProduct(Product product) throws DaoException {
		String sql = "update products set name=?, category=?, price=? where id=?";
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				) {
			stmt.setString(1, product.getName());
			stmt.setString(2, product.getCategory());
			stmt.setDouble(3, product.getPrice());
			stmt.setInt(4, product.getId());

			stmt.executeUpdate();
		} catch (Exception ex) {
			throw new DaoException(ex);
		}

	}

	@Override
	public void deleteProduct(int id) throws DaoException {
		String sql = "delete from products where id=?";

		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				) {

			stmt.setInt(1, id);
			stmt.executeUpdate();

		} catch (Exception ex) {
			throw new DaoException(ex);
		}
	}

	@Override
	public List<Product> getProducts() throws DaoException {
		List<Product> list = new ArrayList<>();

		String sql = "select * from products";
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();) {

			while (rs.next()) {
				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				list.add(p);
			}
		} catch (Exception ex) {
			throw new DaoException(ex);
		}
		return list;
	}

	@Override
	public List<Product> getProductsByPriceRange(double min, double max) throws DaoException {
		List<Product> list = new ArrayList<>();

		String sql = "select * from products where price between ? and ?";
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				) {

			stmt.setDouble(1, min);
			stmt.setDouble(2, max);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {

				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				list.add(p);
			}

		} catch (Exception ex) {
			throw new DaoException(ex);
		}
		return list;
	}

	@Override
	public List<Product> getProductsByCategory(String category) throws DaoException {
		List<Product> list = new ArrayList<>();

		String sql = "select * from products where category=?";

		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
				) {
			stmt.setString(1, category);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {

				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				list.add(p);
			}
		} catch (Exception ex) {
			throw new DaoException(ex);
		}
		return list;
	}

}
