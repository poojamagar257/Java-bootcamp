package com.slk.training.programs;

import java.util.Date;
import java.util.List;

import com.slk.training.dao.ProductDaoJdbcImpl;
import com.slk.training.entity.Product;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.slk.training.cfg.AppConfig3;
import com.slk.training.dao.DaoException;
import com.slk.training.dao.ProductDao;

public class P04_Main {
	
	public static void main(String[] args) throws DaoException {

		AnnotationConfigApplicationContext ctx;
		ctx = new AnnotationConfigApplicationContext(AppConfig3.class);

		ProductDao dao = ctx.getBean("jdbc", ProductDao.class);
		int pc = dao.count();
		System.out.println("There are " + pc + " products.");
		
		Product product = new Product();
		//Add product in list
//		product.setId(11);
//		product.setName("htc 810");
//		product.setCategory("Mobile Phone");
//		product.setPrice(15000);
//		dao.addProduct(product);
//		
		//getProducts List
		System.out.println("All Products List:");
		List<Product> list=(List<Product>) dao.getProducts();
		for(Product p: list){
			System.out.print("Id = "+p.getId());
			System.out.print(" ,Name = "+p.getName());
			System.out.print(" ,Category = "+p.getCategory());
			System.out.print(" ,Price = "+p.getPrice());
			System.out.println();
		}
		
		
		//getProduct by id
         Product p = dao.getProduct(2);
         System.out.println("Id = "+p.getId()+" ,Name = "+p.getName()+" ,Category = "+p.getCategory()+" ,Price = "+p.getPrice());
        
         //GetProduct by Category
         System.out.println("Product by category:");
         List<Product> list1= dao.getProductsByCategory("LAPTOP");
         for(Product p1: list1){
 			System.out.print("Id = "+p1.getId());
 			System.out.print(" ,Name = "+p1.getName());
 			System.out.print(" ,Category = "+p1.getCategory());
 			System.out.print(" ,Price = "+p1.getPrice());
 			System.out.println();
 		}
         
		// get Products ByPriceRange
         System.out.println("Products by Price Range: ");
         List<Product> list2= dao.getProductsByPriceRange(10000, 20000);
         for(Product p2: list2){
 			System.out.print("Id = "+p2.getId());
 			System.out.print(" ,Name = "+p2.getName());
 			System.out.print(" ,Category = "+p2.getCategory());
 			System.out.print(" ,Price = "+p2.getPrice());
 			System.out.println();
 		}
         
//		dao.updateProduct(product);
//		
		
		ctx.close();
	}

}
