package com.slk.training.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.slk.training.dao.DaoException;
import com.slk.training.dao.DaoFactory;
import com.slk.training.dao.ProductDao;
import com.slk.training.entity.Product;

@WebServlet("/ProductsByCategoryServlet")
public class ProductsByCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String input;
		input = request.getParameter("category");

		if (input == null) {
			response.sendRedirect("./home.html");
			return;
		} else {

			try {
				ProductDao dao = DaoFactory.getProductDao();
				List<Product> list = dao.getProductsByCategory(input);
				
				if (list.size() > 0) {
					out.println("<table style='width:40%'>");
					out.print("<table border='1'>");
					out.println("<thead><th>id</th>");
					out.println("<th>name</th>");
					out.println("<th>price</th></thead>");

					out.println("<tbody>");
					for (Product p : list) {
						out.printf("<tr><td>  %d  </td>", p.getId());
						out.printf("<td>  %s  </td>", p.getName());
						out.printf("<td>  %f  </td>", p.getPrice());
					}
					out.println("</tbody></table>");
				} else {
					System.out.println("no product found for category " + input);
				}
			} catch (DaoException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			out.println("<br><br><hr><a href='./'>visit homepage</a>");
			out.close();
		}
	}
}
