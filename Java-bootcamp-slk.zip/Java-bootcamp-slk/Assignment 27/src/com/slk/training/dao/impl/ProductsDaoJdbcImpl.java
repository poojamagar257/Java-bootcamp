package com.slk.training.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.slk.training.dao.DaoException;
import com.slk.training.dao.ProductDao;
import com.slk.training.entity.Product;

public class ProductsDaoJdbcImpl implements ProductDao {

	private Connection openConnection() throws SQLException, ClassNotFoundException {
		Class.forName("org.h2.Driver");
		String url = "jdbc:h2:tcp://localhost/~/slk_training_2018_12";
		String user = "sa";
		String password = "";
		return DriverManager.getConnection(url, user, password);
	}
	
	@Override
	public Product getProductById(int id) throws DaoException {
 
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement("select * from products wher id=?");
				) {
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				return p;
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return null;
	}

	@Override
	public List<Product> getAllProducts() throws DaoException {
		List<Product> list = new ArrayList<>();
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement("select * from products");
				ResultSet rs = stmt.executeQuery();) {
			
			while (rs.next()) {
				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				list.add(p);
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}

	@Override
	public List<Product> getProductsByCategory(String category) throws DaoException {
		List<Product> list = new ArrayList<>();
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement("select * from products where category=?");
				) {
			
			stmt.setString(1, category);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				
				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				list.add(p);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}

}
