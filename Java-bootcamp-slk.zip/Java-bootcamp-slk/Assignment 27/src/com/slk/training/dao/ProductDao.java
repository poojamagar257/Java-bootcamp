package com.slk.training.dao;

import java.util.List;

import com.slk.training.entity.Product;

public interface ProductDao {

	public Product getProductById(int id) throws DaoException;
	public List<Product> getAllProducts() throws DaoException;
	public List<Product> getProductsByCategory(String category) throws DaoException;
}
