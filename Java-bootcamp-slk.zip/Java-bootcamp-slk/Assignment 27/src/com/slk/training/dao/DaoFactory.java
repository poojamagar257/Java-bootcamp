package com.slk.training.dao;

import com.slk.training.dao.impl.ProductsDaoJdbcImpl;

public  class DaoFactory {

	private static final String discriminator = "JDBC";

	private DaoFactory() {
	}

	public static  ProductDao getProductDao() throws DaoException {
		switch (discriminator.toUpperCase()) {
		case "JDBC":
			 return new ProductsDaoJdbcImpl();
			 
		case "HASHMAP":
			//return new ContactsDaoHashMapIpml();
		case "CSV":
			//return new ContactsDaoCsvImpl();
	
		case "ARRAYLIST":
			// return new ContactsDaoArrayListImpl();
			
		}
		throw new DaoException("No implementation found for discriminator: " + discriminator);
	}
}
