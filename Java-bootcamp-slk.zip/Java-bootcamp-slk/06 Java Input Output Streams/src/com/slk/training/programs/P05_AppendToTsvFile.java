package com.slk.training.programs;

import java.io.FileWriter;
import java.io.PrintWriter;

import com.slk.training.utils.KeyBoardUtil;

public class P05_AppendToTsvFile {

	public static void main(String[] args) {

		String filename= "people.csv";// contains tab separated values
		
		try(FileWriter writer = new FileWriter(filename,true);
				PrintWriter out = new PrintWriter(writer)){

			int id= KeyBoardUtil.getInt("Enter id: ");
			String name= KeyBoardUtil.getString("Enter name :");
			String email= KeyBoardUtil.getString("Enter email id :");
			String city= KeyBoardUtil.getString("Enter city :");
			
			out.printf("\n%d\t%s\t%s\t%s",id,name,email,city);
		}
		catch(Exception e){
			
		}
		System.out.println("Data appened to the file ");
		
	}

}
