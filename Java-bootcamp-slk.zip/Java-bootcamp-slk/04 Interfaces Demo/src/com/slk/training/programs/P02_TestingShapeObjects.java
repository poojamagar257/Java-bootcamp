package com.slk.training.programs;

import com.slk.traing.entity.Circle;
import com.slk.traing.entity.Shape;
import com.slk.traing.entity.Square;
import com.slk.traing.entity.Triangle;

public class P02_TestingShapeObjects {

	public static void main(String[] args) {
		
		Shape[] objects ={
				new Circle(12.34),
				new Triangle(12.0,34.0),
				new Triangle(22.0,12.5),
				new Circle(22.34),
				new Square(23.56),
				new Square(20.0),
				new Circle(13.14),	
		};
		
		for(Shape s: objects){
			s.printArea();
		}
	}

}
