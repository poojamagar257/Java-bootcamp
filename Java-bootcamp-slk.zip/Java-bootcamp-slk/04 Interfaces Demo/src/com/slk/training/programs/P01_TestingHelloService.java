package com.slk.training.programs;

import com.slk.training.service.EnglishHelloService;
import com.slk.training.service.HelloService;
import com.slk.training.service.KannadaHelloService;
import com.slk.training.service.SpanishHelloService;

public class P01_TestingHelloService {

	public static void main(String[] args) {

		HelloService service;
		
		//service = new HelloService();
		//error; interface is like abstract class and can not be instantiated
		
		service = new EnglishHelloService();
		service.greet();
		
		service = new SpanishHelloService();
		service.greet();
		
		service = new KannadaHelloService();
		service.greet();
		
		//lines 17 and 20 are identical for the compiler
		//but produce different outputs based on which object
		//the reference points to
	}

}
