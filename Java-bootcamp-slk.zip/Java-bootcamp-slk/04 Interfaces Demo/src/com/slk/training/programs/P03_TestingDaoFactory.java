package com.slk.training.programs;

import com.slk.training.Dao.DaoFactory;
import com.slk.training.Dao.ProductDao;
import com.slk.training.Dao.ProductDaoFileImpl;

public class P03_TestingDaoFactory {

	public static void main(String[] args) {
		
		ProductDao dao;
		
		//dao = new ProductDaoFileImpl();
		//tight coupling:
		//the application depends on a specific implementation
		//In a large application , the above statement( or the likes of it) may be
		//used in hundreds of places. And if the implementation changes, we have to
		//update in all those places. This is the biggest drawback
		
		//To avoid this, use a factory pattern
		//a factory method is also known as virtual constructor, since it returns a newly
		//constructed object (instead of we creating one).
		
		dao = DaoFactory.newProductDao(); //"jdbc" or "file"
		dao.addProduct();
		dao.getProduct();
		dao.updateproduct();
		dao.deleteProduct();
	}

}
