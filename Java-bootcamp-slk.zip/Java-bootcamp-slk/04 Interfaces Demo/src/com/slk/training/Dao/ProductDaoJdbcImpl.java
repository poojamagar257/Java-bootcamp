package com.slk.training.Dao;

public class ProductDaoJdbcImpl implements ProductDao {

	@Override
	public void addProduct() {
		System.out.println("Adding product into a file..");

	}

	@Override
	public void getProduct() {
		System.out.println("Getting a product details from the file..");

	}

	@Override
	public void updateproduct() {
		System.out.println("Updating product details in the file..");
	}

	@Override
	public void deleteProduct() {
		System.out.println("Deleting a product in a file....");
	}

}
