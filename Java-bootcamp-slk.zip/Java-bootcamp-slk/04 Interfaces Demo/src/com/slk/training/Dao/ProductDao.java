package com.slk.training.Dao;

public interface ProductDao {

	//a Dao interface generally contain CRUD and Query operations
	//This is such an example interface, without proper argument
	//and return types
	
	public void addProduct();//generally takes a Product instance as argument
	public void getProduct();//generally takes Id  as argument and returns a product
	public void updateproduct(); //generally takes a Product instance as argument
	public void deleteProduct(); // generally takes Id as argument
	
	//generally all functions here " throws" a user defined exception(ex, DaoException)

}
