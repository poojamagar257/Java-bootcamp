package com.slk.training.Dao;

public class ProductDaoFileImpl implements ProductDao {

	@Override
	public void addProduct() {
		System.out.println("Adding product into a database table..");

	}

	@Override
	public void getProduct() {
		System.out.println("Getting a product details from the database table..");

	}

	@Override
	public void updateproduct() {
		System.out.println("Updating product details in the database table..");
	}

	@Override
	public void deleteProduct() {
		System.out.println("Deleting a product in a database table....");
	}

}
