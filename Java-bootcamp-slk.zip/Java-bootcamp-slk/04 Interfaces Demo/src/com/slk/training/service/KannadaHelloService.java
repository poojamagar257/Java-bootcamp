package com.slk.training.service;

public class KannadaHelloService implements HelloService {

	@Override
	public void greet() {
		System.out.println("ಹಲೋ ಸ್ನೇಹಿತ - "+from);
	}

}
