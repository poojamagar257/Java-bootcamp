package com.slk.training.service;

public interface HelloService {

	String from = "Pooja";
	
	void greet();
}
