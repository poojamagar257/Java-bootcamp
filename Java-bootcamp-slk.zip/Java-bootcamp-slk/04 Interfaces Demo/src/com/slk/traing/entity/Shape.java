package com.slk.traing.entity;

public interface Shape {
 void printArea();
}
