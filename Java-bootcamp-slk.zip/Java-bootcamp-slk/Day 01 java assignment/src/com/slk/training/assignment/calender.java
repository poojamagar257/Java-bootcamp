package com.slk.training.assignment;

public class calender {

	static boolean isValidDate(int year, int month, int day) {

		switch (month) {
		case 2:
			if (day <= 29 && year % 400 == 0 || year % 4 == 0 && year % 100 != 0 ) {
				if (day <= 29) {
					return true;
				}
				else{
					return false;
				}
			}
				else if(day<=28) {
				return true;
			}
			
		case 4:
		case 6:
		case 9:
		case 11:
			if (day <= 30) {
				return true;
			}
		default:
			if (day <= 31) {
				return true;
			}
			
		}
		return false;
	}

	public static void main(String[] args) {
         
		int y =2001, m= 6,d=31;
		boolean f =isValidDate(y, m, d);
		System.out.printf(" %d %d %d is validate date: %s",d,m,y,f);
	}

}
