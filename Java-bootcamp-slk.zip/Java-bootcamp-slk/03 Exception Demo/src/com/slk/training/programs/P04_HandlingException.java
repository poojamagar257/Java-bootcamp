package com.slk.training.programs;

import com.slk.training.entity.InvalidIdException;
import com.slk.training.entity.InvalidNameException;
import com.slk.training.entity.InvalidPriceException;
import com.slk.training.entity.Product;

public class P04_HandlingException {

	public static void main(String[] args) {

		try {
			Product p = new Product();
			p.setId(12);
			p.setName("Acer Travelmate Laptop");
			p.setPrice(35000.0);

			System.out.println(p);
		} catch (InvalidIdException e) {
			e.printStackTrace();
		} catch (InvalidNameException e) {
			e.printStackTrace();
		} catch (InvalidPriceException e) {
			e.printStackTrace();
		}

	}

}
