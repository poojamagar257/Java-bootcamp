package com.slk.training.programs;

import com.slk.training.utils.KeyBoardUtil;

public class P06_UsingKeyboardUtil {

	public static void main(String[] args) {
		
		int age = KeyBoardUtil.getInt("Enter your age: ");
		String name = KeyBoardUtil.getString("Enter your name :");
		double height = KeyBoardUtil.getDouble("Enter your height: ");
		
		System.out.println("Name= "+name);
		System.out.println("Age= "+ age +" years.");
		System.out.println("Height= "+height+ "");

	}

}
