package com.slk.training.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/add-name")
public class AddNameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// For Get requests, render the form
		request.getRequestDispatcher("/WEB-INF/pages/name-form.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Step 1: read inputs from request(if any)
		String name = request.getParameter("name");

		// Step 2: call model function(if any)
		// session scope
		HttpSession session = request.getSession();

		// application scope
		ServletContext ctx = getServletContext();

		// for testing purpose, let's log some information about the session
		System.out.println("session.isNew()= " + session.isNew());
		System.out.println("session.getId()= " + session.getId());
		System.out.println();

		List<String> nameList = (List<String>) session.getAttribute("names");
		List<String> nameList2 = (List<String>) ctx.getAttribute("names");

		if (nameList == null) {
			nameList = new ArrayList<String>();
			session.setAttribute("names", nameList);
		}

		if (nameList2 == null) {
			nameList2 = new ArrayList<String>();
			// let's store the data in application scope as well
			ctx.setAttribute("names", nameList2);
		}

		// Step 3:Store the model data in a scope( if required)
		nameList.add(name);
		nameList2.add(name);

		// Step 4: forward/redirect to a view
		response.sendRedirect("./");
	}

}
