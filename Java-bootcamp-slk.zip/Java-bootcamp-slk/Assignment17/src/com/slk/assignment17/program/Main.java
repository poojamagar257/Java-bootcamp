package com.slk.assignment17.program;

import com.slk.assignment17.entity.Circle;
import com.slk.assignment17.entity.Rectangle;
import com.slk.assignment17.entity.Shape;
import com.slk.assignment17.entity.Square;

public class Main {

	public static void main(String[] args) {
		//
		Shape[] shapes = { new Circle("Blue", true, 20.20), new Rectangle("red", false, 10, 20),
				new Square("black", true, 20)

		};

		for (Shape s : shapes) {
			if (s instanceof Circle) {
				Circle c = (Circle) s;
				System.out.println(s.toString() + " And Perimeter = "+c.getPerimeter()+"and Area =" +c.getArea());
			} else if (s instanceof Rectangle) {
				Rectangle r = (Rectangle) s;
				System.out.println(s.toString() + " And Perimeter = "+r.getPerimeter()+"and Area =" +r.getArea());
			} else if (s instanceof Square) {
				Square q = (Square) s;

				System.out.println(s.toString() + " And Perimeter = "+q.getPerimeter()+"and Area =" +q.getArea());
			}
		}
	}

}
