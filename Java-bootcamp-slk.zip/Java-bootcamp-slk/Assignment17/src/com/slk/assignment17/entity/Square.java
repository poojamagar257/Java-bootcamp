package com.slk.assignment17.entity;

public class Square extends Rectangle {
	
	public Square() {
		// TODO Auto-generated constructor stub
	}

	
	public Square(double side) {
		super(side,side);
	}
	

	public Square(String color, boolean filled, double side) {
		super();
		// TODO Auto-generated constructor stub
	}


	public double getSide() {
		return getWidth();
	}
	
	public void setSide(double side) {
		setWidth(side);
		setLength(side);
	}
	
	public void setWidth(double side){
		setWidth(side);
		
	}
	public void setLength(double side){
		setLength(side);
		
	}
	
	@Override
	public double getArea() {
		return(getSide()*getSide());
	}
	
	@Override
	public double getPerimeter() {
		return(4*getSide());
	}


	@Override
	public String toString() {
		return "Square [toString()=" + super.toString() + "]";
	}
	
	
	
}
