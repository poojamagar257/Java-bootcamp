package com.slk.assignment18.program;

import java.util.Scanner;

import com.slk.assignment18.util.KeyBoardInput;
@SuppressWarnings("resource")
public class P01_UsingKeyBoardInputs {

	public static boolean isInt(String s) {
		try {
			Integer.parseInt(s);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}

	public static void main(String[] args) {

		int icount = 0;
		int scount = 0;
		int sum = 0;
		String str = "";
		String nstr = "";
		
		Scanner s = new Scanner(System.in);
		loop:
			for (;;) 
			{
			String n = KeyBoardInput.getString("Enter input = ");

			if (isInt(n)) {
				icount += 1;
				nstr = nstr.concat(n) + ",";
				int i = Integer.parseInt(n);
				sum = sum + i;
			} else {
				scount += 1;
				str = str.concat(n) + ",";
			}

			System.out.println("press 1 to continue or 2 to stop");
			int n1 = s.nextInt();

			switch (n1) {

			case 1:
				break;

			case 2:
				break loop;
			}
		}

		System.out.println("Number of inputs = " + (icount + scount));
		System.out.println("Number of integer inputs = " + icount);
		System.out.println("Number of non-integer inputs =" + scount);
		System.out.println("Sum of all integer inputs = " + sum);
		System.out.println("The integer inputs =" + nstr);
		System.out.println("The non-integer inputs =" + str);
	}

}
