package com.slk.assignment18.util;

import java.util.Scanner;
@SuppressWarnings("resource")
public class KeyBoardInput {
  
	private KeyBoardInput() {
	}
	 
	public static int getInt(String message){
		System.out.println(message);
		Scanner sc = new  Scanner(System.in); // do not call sc.close()
		return sc.nextInt();
	}

	
	public static String getString(String message){
		System.out.println(message);
		Scanner sc = new  Scanner(System.in); // do not call sc.close()
		return sc.nextLine();
	}
	
	
}
