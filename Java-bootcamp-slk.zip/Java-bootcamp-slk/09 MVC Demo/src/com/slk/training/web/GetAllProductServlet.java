package com.slk.training.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.slk.training.dao.ProductManager;
import com.slk.training.entity.Product;

@WebServlet({ "/GetAllProductServlet", "/get-all-products" })
public class GetAllProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	//step1: read all the inputs from the request(if any)
		
		//step 2: invoke model functions to get data for the output
		ProductManager pm = new ProductManager();
		List<Product> list = pm.getAllProducts();
		
		//step 3: store the model data in a common place (space) ,so that JSP can access
		//The  "Request" object is like a map, that can contain key/value pairs
		//The other possible scopes are "session"(of type HttpSession), and
		//"application" (of type ServletContext)
		request.setAttribute("product", list);
		
		//step 4: forward the request to appropriate view(JSP)
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/show-products.jsp");
		rd.forward(request, response);
	}

}
